
function myfunction(){
    document.getElementById("currentDate").innerHTML = Date();
}
function changeURL() {
    window.location.href = "/savedConnections";
}

function changeURLUpd() {
    window.location.href = "/savedConnections";
}

function changeURLDel() {
    window.location.href = "/savedConnections";
}
